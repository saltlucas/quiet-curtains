<time class="updated" datetime="<?php echo e(get_post_time('c', true)); ?>"><?php echo e(get_the_date()); ?></time> | <span class="category-links"><?php the_category(', '); ?></span>


