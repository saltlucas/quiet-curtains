<?php $__env->startSection('content'); ?>
  <?php while(have_posts()): ?> <?php (the_post()); ?>
    <div id="content-body" class="content-body" >
      <div class="row">      
        <div id="page-content" class="column small-12 medium-9 page-content">
    			<?php if(has_post_format('link')): ?>
    				<?php echo $__env->make('partials.content-single-link', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    			<?php else: ?>
    				<?php echo $__env->make('partials.content-single-'.get_post_type(), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    			<?php endif; ?>
        </div>
        <?php if(App\display_sidebar()): ?>
          <aside class="sidebar column small-12 large-3">
            <?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </aside>
        <?php endif; ?>
      </div>
  	</div>
  <?php endwhile; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>