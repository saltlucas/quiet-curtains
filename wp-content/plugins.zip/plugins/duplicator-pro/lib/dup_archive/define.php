<?php
defined("ABSPATH") or die("");
//Prevent directly browsing to the file

// Should always match the version of Duplicator Pro that includes the library
define('DUPARCHIVE_VERSION', '3.5.2');