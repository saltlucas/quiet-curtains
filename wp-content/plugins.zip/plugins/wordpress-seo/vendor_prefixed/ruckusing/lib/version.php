<?php

namespace YoastSEO_Vendor;

\define('YoastSEO_Vendor\\RUCKUSING_VERSION', '1.1.0');
