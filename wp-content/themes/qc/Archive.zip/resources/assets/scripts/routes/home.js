export default {
  init() {
    // JavaScript to be fired on the home page
    // Slick Slider
    $('.page-header-slider').slick();
  },
  finalize() {
    // JavaScript to be fired on the home page, after the init JS
  },
};
