<time class="updated" datetime="{{ get_post_time('c', true) }}">{{ get_the_date() }}</time> | <span class="category-links"><?php the_category(', '); ?></span>


